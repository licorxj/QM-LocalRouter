"""示例脚本插件入口。

入口函数签名：run(ctx) -> Any
ctx 仅暴露 manifest.permissions 声明过的能力，越权调用会抛 PermissionError。
"""


def run(ctx):
    ctx.log("示例插件开始执行")
    ctx.log("插件: " + ctx.meta["plugin_id"] + " v" + ctx.meta["version"])
    ctx.log("已授权权限: " + ", ".join(ctx.permissions))

    result = {
        "plugin": ctx.meta["plugin_id"],
        "params": ctx.params,
    }

    # database.read 权限：只读查询
    if ctx.has_permission("database.read"):
        try:
            rows = ctx.database.query("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name LIMIT 20")
            result["tables"] = [r["name"] for r in rows]
            ctx.log("读取到 %d 张数据表" % len(rows))
        except Exception as e:
            result["query_error"] = str(e)

    ctx.log("示例插件执行结束")
    return result
